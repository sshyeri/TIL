

dr = (-3, -3, -2, 2, 3, 3, 2, -2)
dc = (-2, 2, 3, 3, 2, -2, -3, -3)

def search():
    while Q:
        r, c = Q.pop(0)
        for i in range(8):
            nr, nc = r+dr[i], c+dc[i]
            if nr == er and nc == ec: return arr[r][c]
            if 0 <= nr < N and 0 <= nc < N and not arr[nr][nc]:
                arr[nr][nc] = arr[r][c] + 1
                Q.append((nr, nc))
    return 0

for tc in range(int(input())):
    N = int(input())
    sr, sc, er, ec = map(int, input().split())
    arr = [[0]*N for _ in range(N)]
    Q = [(sr, sc)]
    arr[sr][sc], arr[er][ec] = 1, -1
    print("#%d"%(tc+1),search())


