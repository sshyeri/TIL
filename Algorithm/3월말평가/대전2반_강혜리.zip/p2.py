# def pick(n, dsum):
#     global ans
#     if n >= 3:
#         if ans < dsum:
#             ans = dsum
#         return
#     
#
#
#6등분의 합을 구해, 조합으로 3개를 고른 후 차이를 구한다.
#차이의 합이 전에 구한 것 보다 크면 저장한다.

for tc in range(int(input())):
    N, M = map(int, input().split())
    arr = [list(map(int, input().split())) for _ in range(N)]

    # P = [0, 0, 0]
    s = [[[[0]*6 for k in range(j+1, M-1)] for j in range(M-2)] for i in range(N-1)]


    s[0][0][0][0], s[0][0][0][1], s[0][0][0][2] = arr[0][0], arr[0][1], sum(arr[0][2:])
    for k in range(1, N):
        s[0][0][0][3] += arr[k][0]
        s[0][0][0][4] += arr[k][1]
        s[0][0][0][5] += sum(arr[k][2:])
#---------------------------------------------1줄의 1칸

    for k in range(1, M-2):
        s[0][0][k][0] = s[0][0][0][0]
        s[0][0][k][1] = s[0][0][k-1][1] + arr[0][k+1]
        s[0][0][k][2] = s[0][0][k-1][2] - arr[0][k+1]
        s[0][0][k][3] = s[0][0][k-1][3]
        s[0][0][k][4] = s[0][0][k-1][4]
        s[0][0][k][5] = s[0][0][k-1][5]
        for l in range(1, N):
            s[0][0][k][4] += arr[l][k+1]
            s[0][0][k][5] -= arr[l][k+1]
#---------------------------------------------1줄의 1줄

    for j in range(1,M-2):
        for k in range(M-2-j):
            s[0][j][k][0] = s[0][j-1][k][0] + arr[0][j]
            s[0][j][k][1] = s[0][j-1][k][1] + arr[0][j+1]
            s[0][j][k][2] = s[0][j-1][k][2] - arr[0][j+1]
            s[0][j][k][3] = s[0][j-1][k][3]
            s[0][j][k][4] = s[0][j-1][k][4]
            s[0][j][k][5] = s[0][j-1][k][5]
            for l in range(1, N):
                s[0][j][k][4] += arr[l][j + 1]
                s[0][j][k][5] -= arr[l][j + 1]

#---------------------------------------------------------------1줄

    for n in range(1, N-1):
        s[n][0][0][0] = s[n-1][0][0][0] + arr[n][0]
        s[n][0][0][1] = s[n-1][0][0][1] + arr[n][1]
        s[n][0][0][2] = s[n-1][0][0][2] + sum(arr[n][2:])
        s[n][0][0][3] = s[n-1][0][0][3] - arr[n][0]
        s[n][0][0][4] = s[n-1][0][0][4] - arr[n][1]
        s[n][0][0][5] = s[n-1][0][0][5] - sum(arr[n][2:])
#-----------------------------------------------------n줄의 1줄
        for k in range(1, M - 2):
            s[n][0][k][0] = s[n][0][0][0]
            s[n][0][k][1] = s[n][0][k - 1][1]
            s[n][0][k][2] = s[n][0][k - 1][2]
            s[n][0][k][3] = s[n][0][k - 1][3]
            s[n][0][k][4] = s[n][0][k - 1][4]
            s[n][0][k][5] = s[n][0][k - 1][5]
            for l in range(1, n):
                s[n][0][k][0] += arr[l][k + 1]
                s[n][0][k][1] -= arr[l][k + 1]
            for l in range(n, N):
                s[n][0][k][4] += arr[l][k + 1]
                s[n][0][k][5] -= arr[l][k + 1]

        for j in range(1, M - 2):
            for k in range(M - 2 - j):
                s[n][j][k][0] = s[n][j - 1][k][0]
                s[n][j][k][1] = s[n][j - 1][k][1]
                s[n][j][k][2] = s[n][j - 1][k][2]
                s[n][j][k][3] = s[n][j - 1][k][3]
                s[n][j][k][4] = s[n][j - 1][k][4]
                s[n][j][k][5] = s[n][j - 1][k][5]
                for l in range(1, n):
                    s[n][j][k][0] += arr[l][j]
                    s[n][j][k][1] -= arr[l][j + 1]
                    s[n][j][k][2] -= arr[l][j + 1]
                for l in range(n+1, N):
                    s[n][j][k][4] += arr[l][j + 1]
                    s[n][j][k][5] -= arr[l][j + 1]


