def picksnack(n, nsum):
    global ans
    if n>=N:
        if nsum < ans: ans = nsum
        return
    if nsum >= ans: return
    for i in range(N):
        if chk[i]: continue
        chk[i] = 1
        if not cost[n][i]:
            cost[n][i] = abs(robot[n*2]-snack[i*2]) + abs(robot[n*2+1]-snack[i*2+1])
        picksnack(n+1, nsum + cost[n][i])
        chk[i] = 0
    return
for tc in range(int(input())):
    N = int(input())
    snack = list(map(int, input().split()))
    robot = list(map(int, input().split()))
    ans = 1000000000
    chk = [0]*N
    cost = [[0]*N for _ in range(N)]
    picksnack(0, 0)
    print("#%d"%(tc+1), ans)

