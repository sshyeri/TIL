str1 = "abc 1, 2 ABC"
print(str1)
str1 =str1.replace("1, 2", "one, two")
print(str1)